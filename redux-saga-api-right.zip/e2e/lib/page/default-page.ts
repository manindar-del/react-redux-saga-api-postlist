export class DefaultPage {
  selectors: {
    
  }
}
